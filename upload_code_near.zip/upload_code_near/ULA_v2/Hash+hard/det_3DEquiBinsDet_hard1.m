function det_loc=det_3DEquiBinsDet_hard(RecPower,loc_eachBeam,num_round)
% 返回最佳码字的行号
%% soft voting
%hash 共num_round轮测量
ave_allBins=mean(RecPower(:,1));
hard_dec_indicies=(RecPower>ave_allBins);
nonZero_Bins=loc_eachBeam(hard_dec_indicies,:); % Stores the high power bins
non_zero_table=tabulate(nonZero_Bins(1:end));
if(sum(hard_dec_indicies)~=0)
    [~,det_loc]=max(non_zero_table(:,2));
else
    det_loc=0;
end
end