function [right_det,RecPower]=func_iterFrames(num_SubBeams,num_Directions,num_Bins,num_Users,W,all_Frame,SNR)
% Performs all_Frame iterations for one multi-beam setting
right_det=0;
% num_round次hash
num_round=log2(num_SubBeams)+1;

% Equi-distance scan: The location of sub-beams in all bins
[loc_eachBeam,~]=func_locations_equi(num_SubBeams,num_Bins);

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
temp_loca=randperm(num_Directions);
% detect uncommon users
det_loc_allUncommon=[]; % Stores the detected uncommon users for each IRS
loc_user=temp_loca(1,1);
All_Beams=[];
RecPower=[];
for round=1:num_round
    if round==1
        round_loc_eachBeam=loc_eachBeam(1:num_Bins,:);
        [All_Beams_eachRound,RecPower_eachRound]=fun_Sel_multiBinsMultiIRS(num_Bins,loc_user,round_loc_eachBeam,W,SNR); 
        All_Beams=[All_Beams;All_Beams_eachRound]; 
    else
        round_Bins=num_Bins/2;
        round_loc_eachBeam=loc_eachBeam(num_Bins+round_Bins*(round-2)+1:num_Bins+round_Bins*(round-1),:);
        [All_Beams_eachRound,RecPower_eachRound]=fun_Sel_multiBinsMultiIRS(round_Bins,loc_user,round_loc_eachBeam,W,SNR); 
        All_Beams=[All_Beams;All_Beams_eachRound];
    end 
    RecPower=[RecPower;RecPower_eachRound];  
end 
% temp=det_3DEquiBinsDet_pre(RecPower,loc_eachBeam,num_SubBeams,num_Bins);
temp=det_3DEquiBinsDet_soft(RecPower,loc_eachBeam,num_SubBeams);
if(loc_user==temp)
    right_det_iter=1;
else
    right_det_iter=0;
end
right_det=right_det+right_det_iter/all_Frame;

 
%% iteration end
end