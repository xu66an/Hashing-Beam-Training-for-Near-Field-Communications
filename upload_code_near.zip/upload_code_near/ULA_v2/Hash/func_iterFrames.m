function [right_det]=func_iterFrames(num_SubBeams,num_Bins,all_Frame,SNR)
% Performs all_Frame iterations for one multi-beam setting

parameters;
right_det=0;
load("matrixW.mat");
codebook=W;
num_codeword=size(codebook,2);
codebook=[codebook,zeros(N,num_SubBeams*num_Bins-num_codeword)];
% num_round次hash
num_round=floor(log2(100));

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    temp=randperm(num_codeword);
    User_loc=temp(1,1);
    steer_user=codebook(:,User_loc);
    SNR0=SNR-25;
    noise=10^(-0.1*SNR0)*(rand(num_round,num_Bins)+0.5);%信号功率为1

    loc_eachBeam=func_locations_hash(num_SubBeams,num_Bins,num_round);

    RecPower=[];
    for round=1:num_round
       round_loc_eachBeam=loc_eachBeam(num_Bins*(round-1)+1:num_Bins*round,:);
       [sigPower_eachRound]=fun_Sel_multiBinsMultiIRS(num_SubBeams,num_Bins,steer_user,round_loc_eachBeam,codebook);
       RecPower_eachRound=sigPower_eachRound/(N^2)+noise(round,:); 
       RecPower=[RecPower,RecPower_eachRound];  
    end 
    
    index=det_3DEquiBinsDet_soft(RecPower,loc_eachBeam,num_round);
    if(User_loc==index)
        right_det_iter=1;
    else
        right_det_iter=0;
    end
    right_det=right_det+right_det_iter/all_Frame;

 
%% iteration end
end