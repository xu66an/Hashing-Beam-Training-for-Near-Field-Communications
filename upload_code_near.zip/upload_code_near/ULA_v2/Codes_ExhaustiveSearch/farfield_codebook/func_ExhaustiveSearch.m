function [right_det]=func_ExhaustiveSearch(all_Frame,SNR)
% This function computes the right probability of Exhaustive Search
parameters;
right_det=0;
%far-field codebook
% t2=atan(repmat(y_s_collect,1,length(x_s_collect))./repmat(x_s_collect,1,length(y_s_collect)));
% t2=-pi/2:pi/180:pi/2;
% sint2=sin(t2);

generated_num = 0 :(N-1);
sint2=(2*(generated_num+1)-N-1)/N;
codebook=exp(1j*pi*sint2'*generated_num);%每行代表一个方向
% 变换到角度域
% beamFFT=fft(codebook,N);
num_codeword=size(codebook,1);

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    % The random single user   

    %近场转向矢量W 128*220(220个采样点的距离r_n)
    load('matrixW.mat');

    temp=randperm(size(W,2));
    r_user=r_n_collect(1,temp(1,1));
    theta_user=theta_n_collect(1,temp(1,1));
    steer_user=W(:,temp(1,1));
    noise=10^(-0.1*SNR)*(rand(1,num_codeword)+0.5);%信号功率为1
    RecPower=zeros(1,num_codeword);
    RecPower=abs(codebook*steer_user).^2/(128^2);

    RecPower_n=RecPower'+noise;
    
       
    [Power_select,loc_max]=max(RecPower_n);
    %
%     loc_user_x=round(User_loc(1,1)/delta_s);
%     loc_user_y=round((User_loc(1,2)-y_s_collect(1))/delta_s);
%     loc_user=loc_user_x*length(y_s_collect)+loc_user_y+1;
    
    if(theta_user==sint2(loc_max))
        right_det_iter=1;
    else
        right_det_iter=0;
    end
    right_det=right_det+right_det_iter;
end  
right_det=right_det/all_Frame;
end

     
 