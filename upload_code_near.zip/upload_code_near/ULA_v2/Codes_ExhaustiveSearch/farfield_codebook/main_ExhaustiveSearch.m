%========================================================a
%  Author: Xu Yuan
%  Date:   2023/3/28;
%  Version: V1.0 
%  Note: This main function is Exhaustive search using far-field codebook
%  Description: 多用户的判决在程序中轮流实现，因此增加迭代次数即可
%%========================================================
clc
clear  

all_Frame=1000;
addpath('D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_v2');
parameters;
clock_iter=1;
Accuracy=zeros(size(SNR_collect));
for SNR=SNR_collect
        Accuracy(1,clock_iter)=func_ExhaustiveSearch(all_Frame,SNR);
    
        clock_iter=clock_iter+1;
end
  
% filename=['E:\论文撰写\NearField\code\fig\ExhaustiveSearch.mat'];
filename=['D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_v2\fig\ExhaustiveSearch_far.mat'];
% save(filename, 'SNR_collect','Accuracy');
%   
 
figure
plot(SNR_collect,Accuracy,'-sg','LineWidth',1)
% title([ 'Exhaustive Search, ', '  Users=',num2str(num_Users),],'interpreter','latex')
% xlabel('Number of measurements','interpreter','latex')
% ylabel('Success beam identification rate','interpreter','latex')
set(gca,'TickLabelInterpreter','latex');
grid on
