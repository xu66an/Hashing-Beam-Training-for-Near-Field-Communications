function [rate]=func_iterFrames(num_SubBeams,num_Bins,all_Frame,SNR)
% Performs all_Frame iterations for one multi-beam setting

parameters;
rate=0;
load("matrixW.mat");
codebook=W;
num_codeword=size(codebook,2);
codebook=[codebook,zeros(N,num_SubBeams*num_Bins-num_codeword)];
% num_round次hash
num_round=floor(log2(num_codeword));

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    a=min(theta_n_collect);
    b=max(theta_n_collect);
    theta_user=a+(b-a)*rand(1);
    a=min(r_n_collect);
    b=max(r_n_collect);
    r_user=a+(b-a)*rand(1);
    steer_user=gen_steering_vector(r_user,theta_user);%row
    SNR0=SNR-25;
    noise=10^(-0.1*SNR0)*(rand(num_round,num_Bins)+0.5);%信号功率为1

    loc_eachBeam=func_locations_hash(num_SubBeams,num_Bins,num_round);

    RecPower=[];
    for round=1:num_round
       round_loc_eachBeam=loc_eachBeam(num_Bins*(round-1)+1:num_Bins*round,:);
       [sigPower_eachRound]=fun_Sel_multiBinsMultiIRS(num_SubBeams,num_Bins,steer_user',round_loc_eachBeam,codebook);
       RecPower_eachRound=sigPower_eachRound/(N^2)+noise(round,:); 
       RecPower=[RecPower,RecPower_eachRound];  
    end 
    
    index=det_3DEquiBinsDet_soft(RecPower,loc_eachBeam,num_round);
    Power_select=abs(steer_user*codebook(:,index)).^2/N^2;
    snr=Power_select/mean(mean(noise));
    rate=rate+log2(1+snr*10^2.5)/all_Frame;
 
%% iteration end
end