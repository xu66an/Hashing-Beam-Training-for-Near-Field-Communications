%========================================================a
%  Author: Xu Yuan;
%  Date:   2023/3/27;
%  Version: V1.0   
%  Description:  No RIS ,用户轮流
%%========================================================

clc
clear  

all_Frame=800; 
% addpath('E:\论文撰写\NearField\code');
parameters;

clock_iter=1;

num_Bins=8;
load("matrixW.mat");
num_SubBeams=ceil(size(W,2)/num_Bins);

Rate=zeros(size(SNR_collect));
for SNR=SNR_collect
    Rate(1,clock_iter)=func_iterFrames(num_SubBeams,num_Bins,all_Frame,SNR);

    clock_iter=clock_iter+1;
end
filename=['E:\论文撰写\NearField\code_near\ULA_rate\N_128\fig\Hash_Bins',num2str(num_Bins),'.mat'];
% filename=['D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_rate\fig\Hash_Bins',num2str(num_Bins),'.mat'];
save(filename, 'SNR_collect','Rate');

% delta_s_collect=[4*d:2*d:10*d,20*d:10*d:70*d];
% SNR=15;
% scantime_hash=zeros(size(delta_s_collect));
% for Delta_s=delta_s_collect
%         scantime_hash(1,clock_iter)=time_hash(Delta_s,num_Bins);
%         
%         clock_iter=clock_iter+1;
% end
% filename=['E:\论文撰写\NearField\code\fig_time\Hash_Bins',num2str(num_Bins),'.mat'];
% save(filename, 'delta_s_collect','scantime_hash');

figure
plot(SNR_collect,Rate,'-ob','LineWidth',1)
% title(['Equi-Multi-Beam, Sub-Beams=', num2str(num_SubBeams),', Users=', num2str(num_Users),', Common users=', num2str(common_Users),', IRS=',num2str(num_IRS)],'Interpreter','latex')
grid on
% ylabel('Success beam identification rate','Interpreter','latex')
% xlabel('SNR','Interpreter','latex')

 