%========================================================a
%  Author: Xu Yuan;
%  Date:   2023/3/27;
%  Version: V1.0 
%  Note: This main function is Hierarchical search (with/wo multi-path)
%  Description: The number of user is 1
%%========================================================

clc
clear  
 
all_Frame=300; 
addpath('E:\论文撰写\NearField\code');
parameters;

clock_iter=1;

Accuracy=zeros(size(SNR_collect));
Rate=zeros(size(SNR_collect));
for SNR=SNR_collect
        [Accuracy(1,clock_iter),Rate(1,clock_iter)]=func_HierarchicalSearch(all_Frame,SNR);
        
        clock_iter=clock_iter+1;
end
filename=['E:\论文撰写\NearField\code\fig\HierarchicalSearch.mat'];
% save(filename, 'SNR_collect','Accuracy');

% delta_s_collect=[4*d:2*d:10*d,20*d:10*d:70*d];
% SNR=15;
% scantime_exhaust=zeros(size(delta_s_collect));
% scantime_hier=zeros(size(delta_s_collect));
% for Delta_s=delta_s_collect
%         [scantime_exhaust(1,clock_iter),scantime_hier(1,clock_iter)]=time_HierarchicalSearch(all_Frame,Delta_s,SNR);
%         
%         clock_iter=clock_iter+1;
% end
% filename=['E:\NearField\fig_time\ExhaustiveSearch.mat'];
% save(filename, 'delta_s_collect','scantime_exhaust');
% filename=['E:\NearField\fig_time\HierarchicalSearch.mat'];
% save(filename, 'delta_s_collect','scantime_hier');

figure
plot(SNR_collect,Rate,'-ob','LineWidth',1)
% title(['Hierarchical Search, ',' Users=',num2str(num_Users),' ,Multi-path=',num2str(multi_path_NearNum),' ,Multi-path fading=',num2str(multi_path_damping)],'interpreter','latex')
% xlabel('SNR','interpreter','latex')
% ylabel('Success beam identification rate','interpreter','latex')
set(gca,'TickLabelInterpreter','latex');
grid on

