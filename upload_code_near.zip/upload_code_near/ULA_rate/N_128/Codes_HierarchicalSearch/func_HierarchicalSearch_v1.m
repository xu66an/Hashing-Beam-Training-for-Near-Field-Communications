function [right_det]=func_HierarchicalSearch(all_Frame,SNR)
% This function computes the error probability of Hierarchical Search
parameters;
right_det=0;

N_linspace=4;
load("matrixW.mat")
delta_theta=theta_n_collect(1,2)-theta_n_collect(1,1);
sorted_theta=theta_n_collect;
sorted_r=sort(unique(r_n_collect));
delta_r=sorted_r(1,end)-sorted_r(1,end-1);
for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    load('matrixW.mat');
    temp=randperm(size(W,2));
    r_user=r_n_collect(1,temp(1,1));
    theta_user=theta_n_collect(1,temp(1,1));
    steer_user=W(:,temp(1,1));
    % Hierarchical scan: The location of sub-beams in each round
    round=1;
    theta_fb=sorted_theta(1,end)-sorted_theta(1,1);%区间长度
    r_fb=sorted_r(1,end)-sorted_r(1,1);
    while(theta_fb>=delta_theta || r_fb>=delta_r) % 第round层
        codebook=[];
        r_c=[];
        theta_c=[];
        for i=1:2
            for j=1:2
                theta0=sorted_theta(1,1)+(2*i-1)*theta_fb/4;
                r0=sorted_r(1,1)+(2*j-1)*r_fb/4;
                codebook=[codebook;gen_steering_vector(r0,theta0)];
                r_c=[r_c,r0];
                theta_c=[theta_c,theta0];
            end
        end
        num_codeword=size(codebook,1);
        noise=10^(-0.1*SNR)*(rand(1,num_codeword)+0.5);%defined as信号功率为1/noise
        RecPower=abs(codebook*steer_user).^2/(N^2);
        RecPower_n=RecPower'+noise;
                
        [Power_select,index_max]=max(RecPower_n);
        r1=r_c(index_max);
        theta1=theta_c(index_max);
        sorted_r=[r1-r_fb/4,r1+r_fb/4];
        sorted_theta=[theta1-theta_fb/4,theta1+theta_fb/4];
        theta_fb=sorted_theta(1,end)-sorted_theta(1,1);%区间长度
        r_fb=sorted_r(1,end)-sorted_r(1,1);
        round=round+1;
    end

    if(r1==r_user && theta1==theta_user)
        right_det_iter=1;
    else
        right_det_iter=0;
    end
    right_det=right_det+right_det_iter;
end
right_det=right_det/all_Frame;
end  

     
 