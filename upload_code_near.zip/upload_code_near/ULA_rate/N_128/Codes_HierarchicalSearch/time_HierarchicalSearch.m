function [time_exhaust,time_hier]=time_HierarchicalSearch(all_Frame,Delta_s,SNR)
% 扫描时间（slot)

parameters;
time_hier=0;
x_s_collect=50*d:Delta_s:200*d;
y_s_collect=-600*d:Delta_s:600*d;
codebook=[];
for i=1:length(x_s_collect)
    for j=1:length(y_s_collect)
        codebook=[codebook;gen_steering_vector(x_s_collect(i),y_s_collect(j))];
    end
end
num_codeword=size(codebook,1);
time_exhaust=num_codeword;
x_user=x_s_collect(end)*rand(1,all_Frame)+10*d;%x只测试正向
y_user=y_s_collect(end)*(2*rand(1,all_Frame)-1);

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    User_loc=[x_user(frame),y_user(frame)];
    steer_user=gen_steering_vector(User_loc(1,1),User_loc(1,2));
    noise=10^(-0.1*SNR)*(rand(1,num_codeword)+0.5);%信号功率为1
     
    % Hierarchical scan: The location of sub-beams in each round
    loc_codebook_update=1:num_codeword;
    round=1;
    while(length(loc_codebook_update)>1)
        mid=floor(length(loc_codebook_update)/2);
        power_beam_1=abs(steer_user*codebook(loc_codebook_update(1:mid),:)').^2;
        power_beam_2=abs(steer_user*codebook(loc_codebook_update(1+mid:end),:)').^2;
        power1=sum(power_beam_1)+noise(2*round-1);
        power2=sum(power_beam_2)+noise(2*round);
        if(power1>power2)
            loc_codebook_update=1:mid;
        else
            loc_codebook_update=mid+1:length(loc_codebook_update);
        end
        round=round+1;
    end
    time_hier=time_hier+round*2/all_Frame;

end

