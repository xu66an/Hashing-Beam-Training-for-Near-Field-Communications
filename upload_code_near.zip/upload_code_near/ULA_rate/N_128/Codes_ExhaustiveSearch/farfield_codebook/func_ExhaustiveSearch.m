function [rate]=func_ExhaustiveSearch(all_Frame,SNR)
% This function computes the right probability of Exhaustive Search
parameters;
rate=0;
%far-field codebook
% t2=atan(repmat(y_s_collect,1,length(x_s_collect))./repmat(x_s_collect,1,length(y_s_collect)));
% t2=-pi/2:pi/180:pi/2;
% sint2=sin(t2);

generated_num = 0 :(N-1);
sint2=(2*(generated_num+1)-N-1)/N;
codebook=exp(1j*pi*sint2'*generated_num);%每行代表一个方向
% 变换到角度域
% beamFFT=fft(codebook,N);
num_codeword=size(codebook,1);

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    % The random single user   

    %近场转向矢量W 128*220(220个采样点的距离r_n)
    load('matrixW.mat');
    a=min(theta_n_collect);
    b=max(theta_n_collect);
    theta_user=a+(b-a)*rand(1);
    a=min(r_n_collect);
    b=max(r_n_collect);
    r_user=a+(b-a)*rand(1);
    steer_user=gen_steering_vector(r_user,theta_user);%row
    SNR0=SNR-25;
    noise=10^(-0.1*SNR0)*(rand(1,num_codeword)+0.5);%信号功率为1
    RecPower=zeros(1,num_codeword);
    RecPower=abs(codebook*steer_user').^2/(128^2);

    RecPower_n=RecPower'+noise;
    
       
    [Power_select,loc_max]=max(RecPower_n);
    %
%     loc_user_x=round(User_loc(1,1)/delta_s);
%     loc_user_y=round((User_loc(1,2)-y_s_collect(1))/delta_s);
%     loc_user=loc_user_x*length(y_s_collect)+loc_user_y+1;
    snr=(Power_select-noise(1,loc_max))/noise(1,loc_max);
    rate=rate+log2(1+snr*10^2.5);
end  
rate=rate/all_Frame;
end

     
 