function [All_Beams,RecPower]=fun_Sel_multiBinsMultiIRS(num_Bins,steer_user,loc_eachBeam,codebook)
RecPower=[];
beamsFFT=codebook';%200*128维
beam=steer_user;

for index_bins=1:num_Bins
   All_Beams= beamsFFT(loc_eachBeam(index_bins,:),:);
   RecPower_eachBin=sum(abs(beam* All_Beams') )^2/size(loc_eachBeam,2); 
   RecPower=[RecPower;RecPower_eachBin]; 

end

end