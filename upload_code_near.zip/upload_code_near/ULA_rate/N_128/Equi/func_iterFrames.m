function [rate]=func_iterFrames(num_SubBeams,num_Directions,num_Bins,num_Users,W,all_Frame,SNR)
% Performs all_Frame iterations for one multi-beam setting
parameters;
rate=0;
% num_round次hash
num_round=log2(num_SubBeams)+1;

% Equi-distance scan: The location of sub-beams in all bins
[loc_eachBeam,~]=func_locations_equi(num_SubBeams,num_Bins);

for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
load('matrixW.mat')
a=min(theta_n_collect);
b=max(theta_n_collect);
theta_user=a+(b-a)*rand(1);
a=min(r_n_collect);
b=max(r_n_collect);
r_user=a+(b-a)*rand(1);
steer_user=gen_steering_vector(r_user,theta_user);%row
% detect uncommon users
det_loc_allUncommon=[]; % Stores the detected uncommon users for each IRS
All_Beams=[];
RecPower=[];
for round=1:num_round
    if round==1
        round_loc_eachBeam=loc_eachBeam(1:num_Bins,:);
        [All_Beams_eachRound,RecPower_eachRound]=fun_Sel_multiBinsMultiIRS(num_Bins,steer_user,round_loc_eachBeam,W); 
        All_Beams=[All_Beams;All_Beams_eachRound]; 
    else
        round_Bins=num_Bins/2;
        round_loc_eachBeam=loc_eachBeam(num_Bins+round_Bins*(round-2)+1:num_Bins+round_Bins*(round-1),:);
        [All_Beams_eachRound,RecPower_eachRound]=fun_Sel_multiBinsMultiIRS(round_Bins,steer_user,round_loc_eachBeam,W); 
        All_Beams=[All_Beams;All_Beams_eachRound];
    end 
    RecPower=[RecPower;RecPower_eachRound];  
end 
SNR0=SNR-25;
noise=10^(-0.1*SNR0)*(rand(size(RecPower))+0.5);
RecPower=RecPower/(N^2)+noise;%
% temp=det_3DEquiBinsDet(RecPower,loc_eachBeam,num_SubBeams,num_Bins);
temp=det_3DEquiBinsDet_pre(RecPower,loc_eachBeam,num_SubBeams,num_Bins);


if(temp~=0)
    selectPower=abs(steer_user*W(:,temp)).^2/N^2;
    snr=(selectPower)/mean(noise);
    rate=rate+log2(1+snr*10^2.5)/all_Frame;
end
 
%% iteration end
end