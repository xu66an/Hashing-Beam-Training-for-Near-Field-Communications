%========================================================a
%  Author: Xu Yuan;
%  Date:   2022/6/24,  SUTD;
%  Version: V1.0 
%  Note: This main function is Equi-Multi-Beam search  
%  Description:  
%%========================================================

clc
clear  

all_Frame=1000; 
% addpath('D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_v2');
parameters;

Accuracy=zeros(size(SNR_collect));
Rate=zeros(size(SNR_collect));
load('matrixW.mat');

num_Directions=size(W,2);
% Beam Scanning: The Equi-distance Multi-beams Single-user
num_Users=1; % Number of active users within scanning
num_Bins=32; 
 num_SubBeams=num_Directions/num_Bins;
% num_Bins is fixed, increase num_SubBeams (all possible directions)
clock_iter=1; 

for SNR=SNR_collect
      
    [Accuracy(1,clock_iter),Rate(1,clock_iter)]=func_iterFrames(num_SubBeams,num_Directions,num_Bins,num_Users,W,all_Frame,SNR); 

    clock_iter=clock_iter+1;
end

filename=['E:\论文撰写\NearField\code_near\ULA_far\fig\Equi_Bins',num2str(num_Bins),'.mat'];
% filename=['D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_v2\fig\Equi_Bins',num2str(num_Bins),'.mat'];
save(filename, 'SNR_collect','Accuracy','Rate');
figure
plot(SNR_collect,Accuracy,'-ob','LineWidth',1)
% title(['Equi-Multi-Beam, Sub-Beams=', num2str(num_SubBeams),', Users=', num2str(num_Users),', Common users=', num2str(common_Users),', IRS=',num2str(num_IRS)],'Interpreter','latex')
grid on
ylabel('Success beam identification rate','Interpreter','latex')
xlabel('SNR','Interpreter','latex')

 