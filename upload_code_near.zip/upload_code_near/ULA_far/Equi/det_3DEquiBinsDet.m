function det_loc=det_3DEquiBinsDet(RecPower,loc_eachBeam,num_SubBeams,num_Bins)

%% Make decision
ave_allBins=mean(RecPower(1:num_Bins,1));
hard_dec_indicies=(RecPower>ave_allBins);
% temp_nonZero=loc_eachBeam.*repmat(hard_dec_indicies,1,num_SubBeams);
temp_nonZero=loc_eachBeam.*repmat(hard_dec_indicies,1,num_SubBeams);
index_nonZero_candidate=find(temp_nonZero(1:num_Bins,1)~=0);
nonZero_Bins_candidate=loc_eachBeam(index_nonZero_candidate,:); % Stores the high power bins
round_dec=(size(loc_eachBeam,1)-num_Bins)/(num_Bins/2);
for r=1:round_dec
    index_zero=find(temp_nonZero(1+(r+1)*num_Bins/2:(r+2)*num_Bins/2,1)==0);
    zero_Bins=loc_eachBeam((r+1)*num_Bins/2+index_zero,:); 
    nonZero_Bins_candidate=nonZero_Bins_candidate.*(1-ismember(nonZero_Bins_candidate,zero_Bins));
end
index_nonzero=find(temp_nonZero(1+num_Bins:end,1)~=0);
if(sum(size(index_nonzero))>1)
    nonzero_Bins=loc_eachBeam(num_Bins+index_nonzero,:); 
    nonZero_Bins_candidate=nonZero_Bins_candidate.*ismember(nonZero_Bins_candidate,nonzero_Bins);
end
det_loc=reshape(nonZero_Bins_candidate,[],1);
det_loc(det_loc==0)=[];
if(size(det_loc,1)>1)
    det_loc=det_loc(1,1);
end

end