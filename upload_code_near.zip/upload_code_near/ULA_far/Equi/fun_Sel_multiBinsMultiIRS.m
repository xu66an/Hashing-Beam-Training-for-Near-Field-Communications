function [All_Beams,RecPower]=fun_Sel_multiBinsMultiIRS(num_Bins,loc_user,loc_eachBeam,codebook,SNR)
parameters;
RecPower=[];
beamsFFT=codebook';%200*128维
beam=beamsFFT(loc_user,:);

for index_bins=1:num_Bins
   All_Beams= beamsFFT(loc_eachBeam(index_bins,:),:);
   RecPower_eachBin=sum(abs(beam* All_Beams') )^2/size(loc_eachBeam,2); 
   RecPower=[RecPower;RecPower_eachBin]; 

end
noise=10^(-0.1*SNR)*(rand(size(RecPower))+0.5);
RecPower=RecPower/(N^2)+noise;%
end