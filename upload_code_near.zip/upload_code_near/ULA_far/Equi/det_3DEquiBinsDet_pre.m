function det_loc=det_3DEquiBinsDet_pre(RecPower,loc_eachBeam,num_SubBeams,num_Bins)

%% Make decision
ave_allBins=mean(RecPower(1:num_Bins,1));
hard_dec_indicies=(RecPower>ave_allBins);
% temp_nonZero=loc_eachBeam.*repmat(hard_dec_indicies,1,num_SubBeams);
temp_nonZero=loc_eachBeam.*repmat(hard_dec_indicies,1,num_SubBeams);
index_nonZero=find(temp_nonZero(:,1)~=0);
zero_Bins=loc_eachBeam;
zero_Bins(index_nonZero,:)=[]; % Stores the low power bins
nonZero_Bins=loc_eachBeam(index_nonZero,:); % Stores the high power bins
 
det_loc_temp=zeros(size(nonZero_Bins,1),num_SubBeams); 
for tt=1:size(nonZero_Bins,1)
    % Detect the right direction
    temp1=[];
    kk=1:size(zero_Bins,1);
    temp1(kk,:)= ismember(zero_Bins(kk,:),nonZero_Bins(tt,:)); 
     
    temp_zeroBins=zero_Bins.*temp1;
    temp_zeroBins(temp_zeroBins==0)=[];
    diff_value=setdiff(nonZero_Bins(tt,:),temp_zeroBins);
    det_loc_temp(tt,:)=[diff_value,zeros(1,num_SubBeams-size(diff_value,2))]; 
end 
if size(nonZero_Bins,1)~=1
    det_loc=zeros(size(nonZero_Bins,1),num_SubBeams);
    for tt=1:size(nonZero_Bins,1)
    for jj=2:size(nonZero_Bins,1)
        if jj>tt
           temp=intersect(det_loc_temp(tt,:),det_loc_temp(jj,:));
           det_loc(tt,:)=[temp,zeros(1,num_SubBeams-size(temp,2))];
        end
    end
    end    
else
    det_loc=det_loc_temp;
end
det_loc=det_loc(:);

det_loc(det_loc==0)=[]; 
det_loc=unique(det_loc);

if isempty(det_loc)
    det_loc=0;
end

if(size(det_loc,1)>1)
    det_loc=det_loc(1,1);
end

end