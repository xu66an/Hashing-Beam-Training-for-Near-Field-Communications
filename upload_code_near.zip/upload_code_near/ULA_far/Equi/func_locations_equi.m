function [loc_eachBeam,loc_compliBeam]=func_locations_equi(num_SubBeams,num_Bins)
% The location of sub-beams in all bins
% Initial beams directions setting
 
% The first round
ii=1:num_SubBeams;
loc_firstBeam(1,ii)=(ii-1)*num_Bins+1; 
jj=1:num_Bins-1;
loc_firstBeam(jj'+1,:)=loc_firstBeam(1,:)+jj'; 
 

for round=1:log2(num_SubBeams)
    if round==1
        half_beams=num_SubBeams/2;
        half_bins=1:num_Bins/2; 
        loc_eachBeam_round(num_Bins/2*(round-1)+1:num_Bins/2*(round-1)+num_Bins/2,1:num_SubBeams)=[loc_firstBeam(half_bins,1:half_beams),loc_firstBeam(half_bins+num_Bins/2,(half_beams+1):end)];
        loc_compli_round(num_Bins/2*(round-1)+1:num_Bins/2*(round-1)+num_Bins/2,1:num_SubBeams)=[loc_firstBeam(half_bins,(half_beams+1):end),loc_firstBeam(half_bins+num_Bins/2,1:half_beams)];
    else
        half_beams=half_beams/2;
        cc=1;
        while cc+half_beams<=num_SubBeams
            loc_eachBeam_round(num_Bins/2*(round-1)+1:num_Bins/2*(round-1)+num_Bins/2,cc:cc+2*half_beams-1)=[loc_firstBeam(half_bins,cc:cc+half_beams-1),loc_firstBeam(half_bins+num_Bins/2,cc+half_beams:cc+2*half_beams-1)];
            cc=cc+2*half_beams;
        end
%         loc_compli_round(num_Bins/2*(round-1)+1:num_Bins/2*(round-1)+num_Bins/2,1:num_SubBeams)=[];
    end
end
 
% New bins
loc_eachBeam=[loc_firstBeam;loc_eachBeam_round];
loc_compliBeam=[];

end