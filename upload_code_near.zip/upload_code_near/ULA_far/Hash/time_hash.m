function time=time_hash(Delta_s,num_Bins)
% 扫描时间（slot)

parameters;
x_s_collect=50*d:Delta_s:200*d;
y_s_collect=-600*d:Delta_s:600*d;

num_codeword=length(x_s_collect)*length(y_s_collect);
num_round=floor(log2(num_codeword));
% num_Bins=ceil(num_codeword/num_SubBeams);
time=num_round*num_Bins;