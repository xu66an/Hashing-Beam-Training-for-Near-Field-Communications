function [RecPower]=fun_Sel_multiBinsMultiIRS(num_SubBeams,num_Bins,steer_user,loc_eachBeam,codebook)

    RecPower=[];
    for index_bins=1:num_Bins
       All_Beams= codebook(:,loc_eachBeam(index_bins,:));
       RecPower_eachBin=sum(abs(steer_user'*All_Beams)).^2/num_SubBeams; 
       RecPower=[RecPower,RecPower_eachBin]; 
    end
end