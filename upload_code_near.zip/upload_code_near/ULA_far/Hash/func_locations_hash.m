function loc_eachBeam=func_locations_hash(num_SubBeams,num_Bins,num_round)
% hash

num_Directions=num_SubBeams*num_Bins;
loc_eachBeam=[];
for round=1:num_round
    temp=randperm(num_Directions)';
    for i=1:num_Bins
        % well spaced
        loc_eachBeam_round(i,1:num_SubBeams)=temp(i:num_Bins:end);
    end
    loc_eachBeam=[loc_eachBeam;loc_eachBeam_round];
end

end