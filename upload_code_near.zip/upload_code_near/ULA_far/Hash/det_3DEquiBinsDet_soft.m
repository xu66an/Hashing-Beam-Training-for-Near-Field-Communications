function det_loc=det_3DEquiBinsDet_soft(RecPower,loc_eachBeam,num_round)
% 返回最佳码字的行号
%% soft voting
%hash 共num_round轮测量
[RecPower_sorted,index_sorted]=sort(RecPower,'descend');
soft_dec_index=index_sorted(1:num_round);
nonZero_Bins=loc_eachBeam(soft_dec_index,:); % Stores the high power bins
non_zero_table=tabulate(nonZero_Bins(1:end));
[~,det_loc]=max(non_zero_table(:,2));

end