% addpath('E:\论文撰写\NearField\code');
% parameters;
% Z_Delta=N^2*d^2/(2*beta_Delta^2*wave_length);
% W=[];
% r_n_collect=[];
% theta_n_collect=[];
% for nn=1:N
%     theta_n=(2*nn-N-1)/N;
%     s=0;
%     r_n=Inf;
%     while r_n>rho_min
%         s=s+1;
%         r_n=1/s*Z_Delta*(1-theta_n^2);
%         b_ns=gen_steering_vector(r_n,theta_n);
%         W=[W,b_ns'];
%         r_n_collect=[r_n_collect,r_n];
%         theta_n_collect=[theta_n_collect,theta_n];
%     end
% end
% W_a=zeros(N,N);
% for nn=1:N
%     theta_n=(2*nn-N-1)/N;
%     isequal=theta_n==theta_n_collect;
%     W_a(:,nn)=sum(W.*repmat(isequal,N,1),2);
% end
% select_beam=fftshift(fft(W_a,N),1);
% N=128;%天线数
% nn=1:N;
% theta_n=(2*nn-N-1)/N;
% beams=exp(1j*pi*(nn-1)'*theta_n);
% beamsFFT=fftshift(fft(beams,N),1);  
% 
% blue = [0.00,0.45,0.74];
% orange = [0.85,0.33,0.10];
% yellow = [0.93,0.69,0.13];
% purple = [0.49,0.18,0.56];
% red = [0.64,0.08,0.18];
% black = [0.15,0.15,0.15];
% green = [0.4660,0.6740,0.1880];
% figure('position',[400,100,1000,700])
% t2=asin(theta_n);
% 
% plot(t2,abs(select_beam(20,:)),color=blue,linewidth=2)
% hold on
% plot(t2,abs(beamsFFT(20,:)),color=orange,linewidth=2);
% set(gca,'FontSize',18,'TickLabelInterpreter','latex');

parameters;
Z_Delta=N^2*d^2/(2*beta_Delta^2*wave_length);
W=[];
r_n_collect=[];
theta_n_collect=[];
for nn=1:N
    theta_n=(2*nn-N-1)/N;
    s=1;
        r_n=1/s*Z_Delta*(1-theta_n^2);
        b_ns=gen_steering_vector(r_n,theta_n);
        W=[W,b_ns'];
        r_n_collect=[r_n_collect,r_n];
        theta_n_collect=[theta_n_collect,theta_n];
end

select_beam=fftshift(fft(W,N),1);
N=128;%天线数
nn=1:N;
theta_n=(2*nn-N-1)/N;
beams=exp(1j*pi*(nn-1)'*theta_n);
beamsFFT=fftshift(fft(beams,N),1);  

blue = [0.00,0.45,0.74];
orange = [0.85,0.33,0.10];
yellow = [0.93,0.69,0.13];
purple = [0.49,0.18,0.56];
red = [0.64,0.08,0.18];
black = [0.15,0.15,0.15];
green = [0.4660,0.6740,0.1880];
% figure('position',[400,100,1000,700])
figure('position',[400,100,800,700])
t2=asin(theta_n);

plot(t2,abs(select_beam(end-20,:)),color=blue,linewidth=2)
hold on
plot(t2,abs(beamsFFT(20,:)),color=orange,linewidth=2);
set(gca,'FontSize',18,'TickLabelInterpreter','latex');