% 极域变换矩阵
addpath('D:\1_xuyuan\论文撰写\Near-field training\NearField\code_near\ULA_v2');
parameters;
Z_Delta=N^2*d^2/(2*beta_Delta^2*wave_length);
W=[];
r_n_collect=[];
theta_n_collect=[];
for nn=1:N
    theta_n=1*(2*nn-N-1)/N;
%     s=0;
%     r_n=Inf;
%     while r_n>rho_min
%         s=s+1;
%         r_n=1/s*Z_Delta*(1-theta_n^2);
%         b_ns=gen_steering_vector(r_n,theta_n);
%         W=[W,b_ns'];
%         r_n_collect=[r_n_collect,r_n];
%         theta_n_collect=[theta_n_collect,theta_n];
%     end
    r_n=1e5;
    b_ns=gen_steering_vector(r_n,theta_n);
    W=[W,b_ns'];
    r_n_collect=[r_n_collect,r_n];
    theta_n_collect=[theta_n_collect,theta_n];
end
save('matrixW.mat','W','r_n_collect','theta_n_collect');