%x_s的正负没有影响，因为x_antenna=0
function vec_steer=gen_steering_vector(x_s,y_s)
    parameters;
    dist=sqrt((x_s-x_antenna).^2+(y_s-y_antenna).^2);
    vec_steer=exp(-j*2*pi/wave_length.*dist);
end