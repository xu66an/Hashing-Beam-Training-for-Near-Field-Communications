function [right_det,rate]=func_ExhaustiveSearch(all_Frame,SNR)
% This function computes the right probability of Exhaustive Search
parameters;
right_det=0;
rate=0;
load("matrixW.mat");
polar_Codebook=W;
num_codeword=size(polar_Codebook,2);
for frame=1:all_Frame
%% Each iteration: user geneartion; bins generation; detection
    % The random single user    
%     User_loc=[x_user(frame),y_user(frame)];
%     steer_user=gen_steering_vector(User_loc(1,1),User_loc(1,2));
    temp=randperm(num_codeword);
    User_loc=temp(1,1);
    steer_user=polar_Codebook(:,User_loc);
    SNR0=SNR-25;
    noise=10^(-0.1*SNR0)*(rand(num_codeword,1)+0.5);%defined as信号功率为1/noise
    RecPower=abs(steer_user'*polar_Codebook).^2/128^2;
%     pathloss_square=10^(Alpha)/r_n_collect(1,User_loc)^Beta;%大尺度的平方
    pathloss_square=1;%忽略大尺度信道增益
%     pathloss_square=1/r_n_collect(1,User_loc)^Beta;
    RecPower_n=RecPower*pathloss_square+noise';
    
       
    [Power_select,loc_max]=max(RecPower_n);
    snr=(Power_select-noise(loc_max,1))/noise(loc_max,1);
    rate=rate+log2(1+snr*10^2.5);
    
%     loc_user_x=round((User_loc(1,1)-x_s_collect(1))/delta_s);
%     loc_user_y=round((User_loc(1,2)-y_s_collect(1))/delta_s);
%     loc_user=loc_user_x*length(y_s_collect)+loc_user_y+1;
    
    if(User_loc==loc_max)
        right_det_iter=1;
    else
        right_det_iter=0;
    end
    right_det=right_det+right_det_iter;
end
right_det=right_det/all_Frame;
rate=rate/all_Frame;
end

     
 