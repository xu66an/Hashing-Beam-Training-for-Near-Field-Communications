%[-90,90]的码本
addpath('E:/NearField');
parameters;

% codebook=[];
% for i=1:length(x_s_collect)
%     for j=1:length(y_s_collect)
%         codebook=[codebook;gen_steering_vector(x_s_collect(i),y_s_collect(j))];
%     end
% end
% save('code_book.mat',"codebook");

% M=length(theta_collect)*length(r_collect);
% Codebook=[];
% for i=1:length(theta_collect)
%     for j=1:length(r_collect)
%         aa=gen_steering_vector(r_collect(1,j),theta_collect(1,i));
%         Codebook=[Codebook,aa'];
%     end
% end
load('matrixW.mat');
Codebook=W;
polar_Codebook=pinv(W)*Codebook*N;
save('polar_codebook.mat','polar_Codebook','r_n_collect');
