SNR_collect=10:5:55;

Freq=30e9;
wave_length=3e8/Freq;
% 天线间隔d
d=wave_length/2;
% 基站天线数
N=128;
Alpha=-28-20*log10(Freq/1e9);
Alpha=Alpha/10;
Beta=2.2;

% 天线的坐标
n=1:N;
x_antenna=zeros(1,N);
y_antenna=(n-(N+1)/2)*d;

beta_Delta=2;
rho_min=3;
% %采样间隔delta_s
% delta_s=10*d;
% 
% x_s_collect=10*d:delta_s:60*d;
% y_s_collect=-290*d:delta_s:300*d;